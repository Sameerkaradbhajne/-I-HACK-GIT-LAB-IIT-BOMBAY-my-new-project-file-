// Knowledge Base: Common Pipeline Errors and Fixes
export interface ErrorPattern {
    id: string;
    pattern: RegExp;
    name: string;
    category: string;
    fix: string;
    confidence: number;
    description: string;
}

export const knowledgeBase: ErrorPattern[] = [
    {
        id: 'npm-econnrefused',
        pattern: /npm ERR! (ECONNREFUSED|ETIMEDOUT|network)/i,
        name: 'NPM Network Error',
        category: 'dependency',
        confidence: 95,
        description: 'NPM registry connection failed',
        fix: `# Add retry logic for npm install
before_script:
  - npm config set fetch-retries 5
  - npm config set fetch-retry-mintimeout 20000
  - npm config set fetch-retry-maxtimeout 120000
  - npm install`
    },
    {
        id: 'docker-oom',
        pattern: /OOMKilled|out of memory|Cannot allocate memory/i,
        name: 'Out of Memory',
        category: 'resource',
        confidence: 90,
        description: 'Container ran out of memory',
        fix: `# Increase memory limit
variables:
  DOCKER_DRIVER: overlay2
  
build:
  script:
    - docker build --memory=2g --memory-swap=2g .`
    },
    {
        id: 'test-timeout',
        pattern: /timeout|timed out|ETIMEDOUT/i,
        name: 'Test Timeout',
        category: 'testing',
        confidence: 85,
        description: 'Tests exceeded time limit',
        fix: `# Increase test timeout
test:
  script:
    - npm test -- --timeout=10000
  timeout: 30m`
    },
    {
        id: 'missing-env',
        pattern: /environment variable.*not (set|found)|undefined.*env/i,
        name: 'Missing Environment Variable',
        category: 'configuration',
        confidence: 92,
        description: 'Required environment variable not set',
        fix: `# Add missing environment variables
variables:
  NODE_ENV: production
  # Add your required variables here`
    },
    {
        id: 'permission-denied',
        pattern: /permission denied|EACCES/i,
        name: 'Permission Denied',
        category: 'security',
        confidence: 88,
        description: 'File or directory permission issue',
        fix: `# Fix file permissions
before_script:
  - chmod +x ./scripts/*.sh
  - chmod -R 755 ./build`
    },
    {
        id: 'port-in-use',
        pattern: /port.*already in use|EADDRINUSE/i,
        name: 'Port Already in Use',
        category: 'resource',
        confidence: 93,
        description: 'Service port is already occupied',
        fix: `# Kill existing process and use dynamic port
before_script:
  - pkill -f "node" || true
  - export PORT=$((3000 + RANDOM % 1000))`
    },
    {
        id: 'git-auth-failed',
        pattern: /authentication failed|could not read Username|Permission denied \(publickey\)/i,
        name: 'Git Authentication Failed',
        category: 'security',
        confidence: 94,
        description: 'Git credentials or SSH key issue',
        fix: `# Use CI/CD token for git operations
before_script:
  - git config --global credential.helper store
  - echo "https://gitlab-ci-token:$CI_JOB_TOKEN@gitlab.com" > ~/.git-credentials`
    },
    {
        id: 'cache-corruption',
        pattern: /cache.*corrupt|integrity check failed|EINTEGRITY/i,
        name: 'Cache Corruption',
        category: 'dependency',
        confidence: 87,
        description: 'Package cache is corrupted',
        fix: `# Clear and rebuild cache
before_script:
  - rm -rf node_modules package-lock.json
  - npm cache clean --force
  - npm install
  
cache:
  key: \${CI_COMMIT_REF_SLUG}
  paths:
    - node_modules/`
    }
];

export function findMatchingPattern(errorLog: string): ErrorPattern | null {
    for (const pattern of knowledgeBase) {
        if (pattern.pattern.test(errorLog)) {
            return pattern;
        }
    }
    return null;
}
