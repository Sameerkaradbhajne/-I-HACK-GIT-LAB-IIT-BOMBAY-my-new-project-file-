import * as vscode from 'vscode';
import axios from 'axios';
import * as path from 'path';
import * as fs from 'fs';
import { findMatchingPattern } from './knowledgeBase';
import { initStats, recordFix, stats } from './stats';


// --- CONFIGURATION ---
const GITLAB_TOKEN = 'glpat-YVfqdwWMizq5YdVaYOA9Im86MQp1Oml1bWs1Cw.01.120ivgfv7';
const PROJECT_ID = '76236303';

// --- AI SERVICE ---
async function askAI(prompt: string): Promise<string> {
    try {
        // Try Pollinations (GET request is more reliable for them)
        const url = `https://text.pollinations.ai/${encodeURIComponent(prompt)}`;
        const response = await axios.get(url);
        return response.data;
    } catch (error: any) {
        console.error('AI API Error:', error.message);

        // --- MOCK MODE (OFFLINE BACKUP) ---
        vscode.window.showWarningMessage("⚠️ AI Unreachable. Using Offline Backup Mode.");

        const p = prompt.toLowerCase();

        if (p.includes("react") || p.includes("login")) {
            return `import React, { useState } from 'react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Login:", email, password);
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px', maxWidth: '300px' }}>
      <h2>Login</h2>
      <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" required />
      <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" required />
      <button type="submit">Sign In</button>
    </form>
  );
}`;
        }

        if (p.includes("python") || p.includes("csv")) {
            return `import csv

def parse_csv(file_path):
    try:
        with open(file_path, mode='r') as file:
            csv_reader = csv.DictReader(file)
            data = [row for row in csv_reader]
            return data
    except FileNotFoundError:
        print(f"Error: File {file_path} not found.")
        return []

# Example Usage
if __name__ == "__main__":
    results = parse_csv('data.csv')
    for row in results:
        print(row)`;
        }

        if (p.includes("pipeline") || p.includes("fix")) {
            return `**Diagnosis:** Missing file 'missing_script.py'.\n\n**Fix:**\n\`\`\`bash\ntouch missing_script.py\n\`\`\``;
        }

        if (p.includes("security") || p.includes("vulnerability")) {
            return `// 🛡️ SECURITY FIX APPLIED
// ❌ Original: const API_KEY = "12345-ABCDE"; (Hardcoded Secret)
// ✅ Fixed: Use Environment Variables

const API_KEY = process.env.API_KEY; // Loaded securely

function connect() {
    if (!API_KEY) {
        throw new Error("API_KEY is missing!");
    }
    console.log("Connected securely.");
}`;
        }

        return "// Error: AI Unavailable and no backup found for this prompt.";
    }
}

export function activate(context: vscode.ExtensionContext) {
    console.log('🚀 CodeForge Commander is active!');
    initStats(context.extensionPath);

    // --- FEATURE 1: ISSUE TO CODE ---
    let generateDisp = vscode.commands.registerCommand('codeforge.generateCode', async () => {
        const issueDesc = await vscode.window.showInputBox({
            prompt: "Enter Issue Description",
            placeHolder: "e.g., Create a Python script to parse CSV files"
        });

        if (!issueDesc) return;

        vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "🤖 CodeForge: Generating Code...",
            cancellable: false
        }, async () => {
            try {
                const prompt = `You are an expert coding assistant.
Task: ${issueDesc}
Provide only the code solution. No markdown, no explanations.`;

                const code = await askAI(prompt);

                const doc = await vscode.workspace.openTextDocument({
                    content: code,
                    language: 'javascript'
                });
                await vscode.window.showTextDocument(doc);

                vscode.window.showInformationMessage("✅ Code Generated!");
            } catch (error: any) {
                console.error("Generate Code Error:", error);
                vscode.window.showErrorMessage(`❌ Error: ${error.message}`);
            }
        });
    });

    // --- FEATURE 2: PIPELINE HEALER (WITH PATTERN LEARNING & STATS) ---
    let healDisp = vscode.commands.registerCommand('codeforge.healPipeline', async () => {
        vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "🚑 CodeForge: Analyzing Pipeline...",
            cancellable: false
        }, async () => {
            try {
                const jobsUrl = `https://gitlab.com/api/v4/projects/${PROJECT_ID}/jobs?scope[]=failed&per_page=1`;
                const jobsResponse = await axios.get(jobsUrl, { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } });

                if (jobsResponse.data.length === 0) {
                    vscode.window.showInformationMessage("✅ No failed jobs found!");
                    return;
                }

                const failedJob = jobsResponse.data[0];

                const logUrl = `https://gitlab.com/api/v4/projects/${PROJECT_ID}/jobs/${failedJob.id}/trace`;
                const logResponse = await axios.get(logUrl, { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } });
                const logData = logResponse.data;

                // 🤖 PATTERN LEARNING: Try to match against knowledge base
                const matchedPattern = findMatchingPattern(logData);

                if (matchedPattern) {
                    // ✅ Pattern recognized! Show high-confidence fix
                    recordFix({
                        jobName: failedJob.name,
                        pattern: matchedPattern.name,
                        confidence: matchedPattern.confidence,
                        timeSaved: 120 // Estimated 2 mins saved
                    });

                    const fixContent = `# 🎯 Pattern Recognized! (${matchedPattern.confidence}% Confidence)

## Error: ${matchedPattern.name}
**Category:** ${matchedPattern.category}
**Job:** ${failedJob.name} (ID: ${failedJob.id})

## Description
${matchedPattern.description}

## Suggested Fix
\`\`\`yaml
${matchedPattern.fix}
\`\`\`

---
*This fix was matched from our knowledge base of common CI/CD errors.*
*Confidence: ${matchedPattern.confidence}% based on ${matchedPattern.category} error patterns.*`;

                    const doc = await vscode.workspace.openTextDocument({
                        content: fixContent,
                        language: 'markdown'
                    });
                    await vscode.window.showTextDocument(doc);

                    // Offer to create GitLab issue with the fix
                    const action = await vscode.window.showInformationMessage(
                        `🎯 Pattern matched with ${matchedPattern.confidence}% confidence!`,
                        "Create GitLab Issue with Fix",
                        "Close"
                    );

                    if (action === "Create GitLab Issue with Fix") {
                        try {
                            await axios.post(
                                `https://gitlab.com/api/v4/projects/${PROJECT_ID}/issues`,
                                {
                                    title: `🤖 Auto-Fix: ${matchedPattern.name}`,
                                    description: `## Pattern Learning Auto-Fix\n\n**Confidence:** ${matchedPattern.confidence}%\n**Category:** ${matchedPattern.category}\n\n### Error\n${matchedPattern.description}\n\n### Suggested Fix\n\`\`\`yaml\n${matchedPattern.fix}\n\`\`\`\n\n---\n*Auto-generated by CodeForge Commander Pattern Learning*`,
                                    labels: ['auto-fix', 'ci-cd', matchedPattern.category]
                                },
                                { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } }
                            );
                            vscode.window.showInformationMessage("✅ GitLab Issue created with fix!");
                        } catch (err: any) {
                            vscode.window.showErrorMessage(`Failed to create issue: ${err.message}`);
                        }
                    }

                } else {
                    // ⚠️ No pattern match, use AI fallback
                    recordFix({
                        jobName: failedJob.name,
                        timeSaved: 30 // Estimated 30s saved
                    });

                    const truncatedLog = logData.slice(-2000);
                    const prompt = `Analyze this GitLab CI/CD job failure log and provide a fix.\nLog:\n${truncatedLog}\n\nProvide a short explanation and the corrected code/command.`;
                    const fixSuggestion = await askAI(prompt);

                    const doc = await vscode.workspace.openTextDocument({
                        content: `// 🚨 FAILED JOB: ${failedJob.name} (ID: ${failedJob.id})\n// ⚠️ No pattern match found - Using AI analysis\n\n${fixSuggestion}`,
                        language: 'markdown'
                    });
                    await vscode.window.showTextDocument(doc);

                    // Offer to create MR for AI fix
                    const action = await vscode.window.showInformationMessage(
                        '✅ AI fix ready. Create Merge Request?',
                        'Create MR',
                        'Dismiss'
                    );

                    if (action === 'Create MR') {
                        try {
                            const branchName = `ai-fix/${failedJob.name}-${Date.now()}`;
                            // Create branch
                            await axios.post(
                                `https://gitlab.com/api/v4/projects/${PROJECT_ID}/repository/branches`,
                                { branch: branchName, ref: 'main' },
                                { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } }
                            );

                            // Create MR
                            await axios.post(
                                `https://gitlab.com/api/v4/projects/${PROJECT_ID}/merge_requests`,
                                {
                                    source_branch: branchName,
                                    target_branch: 'main',
                                    title: `🤖 AI Fix: ${failedJob.name}`,
                                    description: `Auto-generated fix from CodeForge Commander (AI fallback).\n\nSuggested Fix:\n${fixSuggestion}`,
                                    remove_source_branch: true
                                },
                                { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } }
                            );

                            vscode.window.showInformationMessage('✅ Merge Request created from AI fix!');
                        } catch (e: any) {
                            vscode.window.showErrorMessage(`❌ MR creation failed: ${e.message}`);
                        }
                    }
                }

                vscode.window.showInformationMessage("🚑 Diagnosis Ready!");

            } catch (error: any) {
                vscode.window.showErrorMessage(`❌ Error: ${error.message}`);
            }
        });
    });

    // --- FEATURE 3: SECURITY SENTINEL ---
    let securityDisp = vscode.commands.registerCommand('codeforge.fixSecurity', async () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage("❌ Open a file to scan for vulnerabilities.");
            return;
        }

        const code = editor.document.getText();

        vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "🛡️ Security Sentinel: Scanning...",
            cancellable: false
        }, async () => {
            try {
                const prompt = `Analyze this code for security vulnerabilities (like hardcoded secrets, SQL injection) and provide a FIXED, secure version.
Code:
${code}

Provide ONLY the fixed code.`;

                const secureCode = await askAI(prompt);

                const doc = await vscode.workspace.openTextDocument({
                    content: secureCode,
                    language: editor.document.languageId
                });
                await vscode.window.showTextDocument(doc, { viewColumn: vscode.ViewColumn.Beside });

                vscode.window.showInformationMessage("🛡️ Security Fix Applied!");
            } catch (error: any) {
                vscode.window.showErrorMessage(`❌ Error: ${error.message}`);
            }
        });
    });

    // --- FEATURE 4: IMPLEMENT GITLAB ISSUE ---
    let implementIssueDisp = vscode.commands.registerCommand('codeforge.implementIssue', async () => {
        vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "📋 Fetching GitLab Issues...",
            cancellable: false
        }, async () => {
            try {
                const issuesUrl = `https://gitlab.com/api/v4/projects/${PROJECT_ID}/issues?state=opened&per_page=10`;
                const issuesResponse = await axios.get(issuesUrl, { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } });

                if (issuesResponse.data.length === 0) {
                    vscode.window.showInformationMessage("✅ No open issues found!");
                    return;
                }

                interface IssueQuickPickItem extends vscode.QuickPickItem {
                    issueData: any;
                }

                const issues: IssueQuickPickItem[] = issuesResponse.data.map((issue: any) => ({
                    label: `#${issue.iid}: ${issue.title}`,
                    description: issue.description?.substring(0, 100) || 'No description',
                    issueData: issue
                }));

                const selected = await vscode.window.showQuickPick(issues, {
                    placeHolder: 'Select a GitLab Issue to implement'
                });

                if (!selected) return;

                const prompt = `You are an expert coding assistant.
Task: Implement this GitLab Issue:
Title: ${selected.issueData.title}
Description: ${selected.issueData.description || 'No description provided'}

Provide only the code solution. No markdown, no explanations.`;

                const code = await askAI(prompt);

                const doc = await vscode.workspace.openTextDocument({
                    content: code,
                    language: 'javascript'
                });
                await vscode.window.showTextDocument(doc);

                vscode.window.showInformationMessage(`✅ Code generated for Issue #${selected.issueData.iid}!`);

            } catch (error: any) {
                vscode.window.showErrorMessage(`❌ Error: ${error.message}`);
            }
        });
    });

    // --- FEATURE 5: PIPELINE STATUS DASHBOARD ---
    let pipelineStatusDisp = vscode.commands.registerCommand('codeforge.viewPipelineStatus', async () => {
        vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "📊 Fetching Pipeline Status...",
            cancellable: false
        }, async () => {
            try {
                const pipelinesUrl = `https://gitlab.com/api/v4/projects/${PROJECT_ID}/pipelines?per_page=10`;
                const pipelinesResponse = await axios.get(pipelinesUrl, { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } });

                if (pipelinesResponse.data.length === 0) {
                    vscode.window.showInformationMessage("✅ No pipelines found!");
                    return;
                }

                interface PipelineQuickPickItem extends vscode.QuickPickItem {
                    pipelineData: any;
                }

                const pipelines: PipelineQuickPickItem[] = pipelinesResponse.data.map((pipeline: any) => {
                    let icon = '🔄';
                    if (pipeline.status === 'success') icon = '✅';
                    if (pipeline.status === 'failed') icon = '❌';
                    if (pipeline.status === 'running') icon = '🔄';

                    return {
                        label: `${icon} Pipeline #${pipeline.id} - ${pipeline.status}`,
                        description: `Branch: ${pipeline.ref} | ${pipeline.created_at}`,
                        pipelineData: pipeline
                    };
                });

                const selected = await vscode.window.showQuickPick(pipelines, {
                    placeHolder: 'Select a pipeline to view details'
                });

                if (!selected) return;

                const info = `# Pipeline #${selected.pipelineData.id}

**Status:** ${selected.pipelineData.status}
**Branch:** ${selected.pipelineData.ref}
**Created:** ${selected.pipelineData.created_at}
**Web URL:** ${selected.pipelineData.web_url}

${selected.pipelineData.status === 'failed' ? '💡 Tip: Run "CodeForge: Heal Pipeline" to get AI-powered fix suggestions!' : ''}
`;

                const doc = await vscode.workspace.openTextDocument({
                    content: info,
                    language: 'markdown'
                });
                await vscode.window.showTextDocument(doc);

            } catch (error: any) {
                vscode.window.showErrorMessage(`❌ Error: ${error.message}`);
            }
        });
    });

    // --- FEATURE 6: GITLAB SAST VULNERABILITIES ---
    let sastDisp = vscode.commands.registerCommand('codeforge.viewSASTVulnerabilities', async () => {
        vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "🛡️ Fetching SAST Vulnerabilities...",
            cancellable: false
        }, async () => {
            try {
                let vulnerabilities: any[] = [];

                // Try to fetch vulnerability reports from GitLab
                try {
                    const vulnUrl = `https://gitlab.com/api/v4/projects/${PROJECT_ID}/vulnerability_findings?per_page=20`;
                    const vulnResponse = await axios.get(vulnUrl, { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } });
                    vulnerabilities = vulnResponse.data;
                } catch (apiError: any) {
                    // If 403 (no access) or 404 (no SAST enabled), use demo data
                    console.log('SAST API not available, using demo data');
                }

                // If no real vulnerabilities, show demo ones for the hackathon
                if (!vulnerabilities || vulnerabilities.length === 0) {
                    vscode.window.showWarningMessage("No SAST reports found. Showing demo vulnerabilities for hackathon.");
                    vulnerabilities = [
                        {
                            id: 'demo-1',
                            name: 'Hardcoded Secret Detected',
                            severity: 'high',
                            description: 'API key found hardcoded in source code',
                            location: { file: 'src/config.js', start_line: 15 }
                        },
                        {
                            id: 'demo-2',
                            name: 'SQL Injection Risk',
                            severity: 'critical',
                            description: 'Unsanitized user input in SQL query',
                            location: { file: 'src/database.js', start_line: 42 }
                        }
                    ];
                }

                interface VulnQuickPickItem extends vscode.QuickPickItem {
                    vulnData: any;
                }

                const vulnItems: VulnQuickPickItem[] = vulnerabilities.map((vuln: any) => {
                    let icon = '⚠️';
                    if (vuln.severity === 'critical') icon = '🔴';
                    if (vuln.severity === 'high') icon = '🟠';
                    if (vuln.severity === 'medium') icon = '🟡';

                    return {
                        label: `${icon} ${vuln.name || vuln.title}`,
                        description: `${vuln.severity?.toUpperCase()} | ${vuln.location?.file || 'Unknown file'}`,
                        vulnData: vuln
                    };
                });

                const selected = await vscode.window.showQuickPick(vulnItems, {
                    placeHolder: 'Select a vulnerability to fix with AI'
                });

                if (!selected) return;

                // Ask AI to fix the vulnerability
                const prompt = `You are a security expert. Fix this vulnerability:
Vulnerability: ${selected.vulnData.name || selected.vulnData.title}
Severity: ${selected.vulnData.severity}
Description: ${selected.vulnData.description}
File: ${selected.vulnData.location?.file}
Line: ${selected.vulnData.location?.start_line}

Provide ONLY the fixed, secure code. No markdown, no explanations.`;

                const secureCode = await askAI(prompt);

                const doc = await vscode.workspace.openTextDocument({
                    content: `// 🛡️ SECURITY FIX\n// Vulnerability: ${selected.vulnData.name || selected.vulnData.title}\n// Severity: ${selected.vulnData.severity}\n\n${secureCode}`,
                    language: 'javascript'
                });
                await vscode.window.showTextDocument(doc);

                vscode.window.showInformationMessage("🛡️ Security Fix Generated!");

            } catch (error: any) {
                vscode.window.showErrorMessage(`❌ Error: ${error.message}`);
            }
        });
    });

    // --- FEATURE 8: AUTO-DEPLOY TO ENVIRONMENT ---
    let autoDeployDisp = vscode.commands.registerCommand('codeforge.autoDeploy', async () => {
        vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "🚀 Initiating Deployment...",
            cancellable: false
        }, async () => {
            try {
                // 1. Ask user to select environment
                const environment = await vscode.window.showQuickPick(
                    ['staging', 'production', 'demo'],
                    { placeHolder: 'Select deployment environment' }
                );
                if (!environment) return;

                // 2. Trigger a new pipeline for the deployment
                // We use the 'main' branch by default
                const triggerUrl = `https://gitlab.com/api/v4/projects/${PROJECT_ID}/pipeline`;

                let pipeline;
                try {
                    // Try with variables first
                    const response = await axios.post(triggerUrl, {
                        ref: 'main',
                        variables: [
                            { key: 'DEPLOY_TARGET', value: environment },
                            { key: 'DEPLOY_ACTION', value: 'deploy' }
                        ]
                    }, { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } });
                    pipeline = response.data;
                } catch (err: any) {
                    console.log('Failed with variables, trying without...', err.response?.data);
                    // Fallback: Try without variables (maybe schema issue)
                    const response = await axios.post(triggerUrl, {
                        ref: 'main'
                    }, { headers: { 'PRIVATE-TOKEN': GITLAB_TOKEN } });
                    pipeline = response.data;
                }

                const deploymentInfo = `# 🚀 Deployment Pipeline Started

**Environment:** ${environment}
**Pipeline ID:** ${pipeline.id}
**Status:** ${pipeline.status}
**Branch:** ${pipeline.ref}
**Web URL:** ${pipeline.web_url}

---
*The CI/CD pipeline is now running to deploy your application.*
*Monitor progress in the "Pipeline Status" dashboard.*`;

                const doc = await vscode.workspace.openTextDocument({
                    content: deploymentInfo,
                    language: 'markdown'
                });
                await vscode.window.showTextDocument(doc);

                vscode.window.showInformationMessage(`✅ Deployment Pipeline Initiated for ${environment}!`);

            } catch (error: any) {
                console.error(error);
                const errorMsg = error.response?.data?.message || error.message;
                if (error.response?.status === 404) {
                    vscode.window.showErrorMessage("❌ Project not found or access denied.");
                } else {
                    vscode.window.showErrorMessage(`❌ Deployment Failed: ${JSON.stringify(errorMsg)}`);
                }
            }
        });
    });

    // --- FEATURE 9: DASHBOARD (WebView) ---
    let dashboardDisp = vscode.commands.registerCommand('codeforge.showDashboard', async () => {
        const panel = vscode.window.createWebviewPanel(
            'codeforgeDashboard',
            'CodeForge Dashboard',
            vscode.ViewColumn.One,
            {
                enableScripts: true,
                localResourceRoots: [vscode.Uri.file(path.join(context.extensionPath, 'src'))]
            }
        );

        const htmlPath = vscode.Uri.file(path.join(context.extensionPath, 'src', 'dashboard.html'));
        const html = await vscode.workspace.fs.readFile(htmlPath);
        panel.webview.html = Buffer.from(html).toString('utf8');

        const sendStats = () => panel.webview.postMessage({
            type: 'stats',
            totalFixes: stats.totalFixes,
            patternMatches: stats.patternMatches,
            aiFallbacks: stats.aiFallbacks,
            timeSaved: stats.timeSaved,
            recentFixes: stats.recentFixes.slice(-5)
        });

        panel.onDidChangeViewState(() => {
            if (panel.visible) sendStats();
        });

        // Initial send
        if (panel.visible) sendStats();

        const disposable = vscode.workspace.onDidChangeConfiguration(() => {
            if (panel.visible) sendStats();
        });
        panel.onDidDispose(() => disposable.dispose());
    });

    // --- FEATURE 10: STATUS BAR ITEM ---
    const myStatusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    myStatusBarItem.command = 'codeforge.showMenu';
    myStatusBarItem.text = '$(rocket) CodeForge';
    myStatusBarItem.tooltip = 'CodeForge Commander: DevSecOps Assistant';
    myStatusBarItem.show();
    context.subscriptions.push(myStatusBarItem);

    let menuDisp = vscode.commands.registerCommand('codeforge.showMenu', async () => {
        const options = [
            { label: '$(dashboard) Show Dashboard', command: 'codeforge.showDashboard' },
            { label: '$(beaker) Heal Pipeline', command: 'codeforge.healPipeline' },
            { label: '$(shield) Fix Security', command: 'codeforge.fixSecurity' },
            { label: '$(rocket) Auto-Deploy', command: 'codeforge.autoDeploy' },
            { label: '$(list-unordered) Implement Issue', command: 'codeforge.implementIssue' }
        ];

        const selection = await vscode.window.showQuickPick(options, {
            placeHolder: 'CodeForge Commander: Select an Action'
        });

        if (selection) {
            vscode.commands.executeCommand(selection.command);
        }
    });

    context.subscriptions.push(generateDisp, healDisp, securityDisp, implementIssueDisp, pipelineStatusDisp, sastDisp, autoDeployDisp, dashboardDisp, menuDisp);
}

export function deactivate() { }
