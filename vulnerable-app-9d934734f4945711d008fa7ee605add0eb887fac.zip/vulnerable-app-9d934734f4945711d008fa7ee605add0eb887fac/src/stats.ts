import * as fs from 'fs';
import * as path from 'path';

export interface FixRecord {
    jobName: string;
    pattern?: string;          // undefined if AI fallback
    confidence?: number;       // 0-100
    timeSaved: number;         // seconds (estimated)
}

export const stats = {
    totalFixes: 0,
    patternMatches: 0,
    aiFallbacks: 0,
    timeSaved: 0,
    recentFixes: [] as FixRecord[]
};

// We will store stats in the user's workspace storage or a local file for this hackathon demo
// For simplicity in this demo, we'll try to use a local file in the extension dir, 
// but in a real extension, context.globalStorageUri is better.
let statsFile = '';

export function initStats(extensionPath: string) {
    statsFile = path.join(extensionPath, 'stats.json');
    loadStats();
}

export function loadStats() {
    if (statsFile && fs.existsSync(statsFile)) {
        try {
            const data = JSON.parse(fs.readFileSync(statsFile, 'utf8'));
            Object.assign(stats, data);
        } catch (_) { }
    }
}

export function recordFix(record: FixRecord) {
    stats.totalFixes++;
    stats.timeSaved += record.timeSaved;
    if (record.pattern) {
        stats.patternMatches++;
    } else {
        stats.aiFallbacks++;
    }
    stats.recentFixes.push(record);
    // Keep only the latest 20 entries
    if (stats.recentFixes.length > 20) stats.recentFixes.shift();

    if (statsFile) {
        try {
            fs.writeFileSync(statsFile, JSON.stringify(stats, null, 2));
        } catch (e) {
            console.error('Failed to save stats:', e);
        }
    }
}
